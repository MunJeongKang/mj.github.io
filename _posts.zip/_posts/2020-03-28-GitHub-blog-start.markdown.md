---
title: GitHub 블로그 시작
author: Munjeong Kang
date: 2020-03-28 18:00:00 +0800
categories: [Memo, Tutorial]
tags: [github]
toc: true
comments: true
---

코딩 새내기의 GitHub 블로그를 시작하려고 한다. 

계정 생성부터 컴퓨터 세팅까지 쉬운게 없다..

이 블로그에는 여러가지 소소한 일상과 현재 공부하고 있는 분야에 대해 적으려 한다.

앞으로 배워야할게 더 많을 것 같다.. ㅠ_ㅠ
